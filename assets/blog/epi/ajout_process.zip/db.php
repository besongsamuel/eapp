<?php
    $dbHost = 'localhost';
    $dbUsername = 'perfex';
    $dbPassword = 'Password01$';
    $dbName = 'script';
    //connect with the database
    $db = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
?>